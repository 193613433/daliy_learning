vot evaluate --workspace . stark_st50_lt
vot analysis --workspace . stark_st50_lt --format html


