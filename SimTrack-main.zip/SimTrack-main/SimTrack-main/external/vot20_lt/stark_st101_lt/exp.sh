vot evaluate --workspace . stark_st101_lt
vot analysis --workspace . stark_st101_lt --format html


