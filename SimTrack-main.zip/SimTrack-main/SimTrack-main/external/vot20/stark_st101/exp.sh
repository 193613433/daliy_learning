vot evaluate --workspace . stark_st101
vot analysis --workspace . stark_st101 --format html