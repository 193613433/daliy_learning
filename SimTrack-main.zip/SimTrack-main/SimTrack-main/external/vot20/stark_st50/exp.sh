vot evaluate --workspace . stark_st50
vot analysis --workspace . stark_st50 --format html


