vot evaluate --workspace . stark_st101_ar
vot analysis --workspace . stark_st101_ar --format html


