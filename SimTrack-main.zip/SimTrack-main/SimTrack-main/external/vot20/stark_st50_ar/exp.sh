vot evaluate --workspace . stark_st50_ar
vot analysis --workspace . stark_st50_ar --format html


