vot evaluate --workspace . stark_s50
vot analysis --workspace . stark_s50 --format html


