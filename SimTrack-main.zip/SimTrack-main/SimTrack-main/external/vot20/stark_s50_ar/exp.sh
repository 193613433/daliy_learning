vot evaluate --workspace . stark_s50_ar
vot analysis --workspace . stark_s50_ar --format html


