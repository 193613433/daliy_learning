from .linear_filter import LinearFilter
